package com.example.spotifyplaylistapp.model.entity;

public enum StyleEnum {
    POP, ROCK, JAZZ
}
